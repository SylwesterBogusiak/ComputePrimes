
// 
// The Prime Spiral (aka Ulam Spiral)
// MARTE.BEST - Sylwester Bogusiak
// https://www.facebook.com/sylwester.bogusiak/ 
// www.marte.best and bogusiak.pl


  let maxN = 10000;
  let step = 6;
  let x = 0;
  let y = 0;
  let dx = 1;
  let dy = 0;
  let segmentLength = 1;
  let segmentPassed = 0;
  let segmentCount = 0;

// Function to test if number is prime
function isPrime(value) {
  if (value == 1) return false;
  for (let i = 2; i <= sqrt(value); i++) {
    if (value % i == 0) {
      return false;
    }
  }
  return true;
}

function setup() {
  createCanvas(800, 800);
  background(255);
  translate(width / 2, height / 2);
  noStroke();
  }
  
  
  
  

function draw() {
 
  
  for (let n = 1; n <= maxN; n++) {

    let lastDigit = n % 10;
    let isColored = false;

    // wybór koloru
    if (lastDigit === 1) {
      fill(0, 0, 0); // RED
      isColored = true;
    } else if (lastDigit === 2) {
      fill(127, 127, 127); // GREY
      isColored = true;
    } else
      if (lastDigit === 3) {
      fill(255, 0, 0); // RED
      isColored = true;
    } else 
      if (lastDigit === 4) {
      fill(0, 127, 127); // R
      isColored = true;
    } else 
      if (lastDigit === 5) {
      fill(127, 127, 0); // 
      isColored = true;
    } else 
      if (lastDigit === 6) {
      fill(0, 255, 0); // GREEN
      isColored = true;
    } else 
      if (lastDigit === 7) {
      fill(0, 127, 0); // RED
      isColored = true;
    } else if (lastDigit === 8) {
      fill(127, 0, 127); // GREEN
      isColored = true;
    } else if (lastDigit === 9) {
      fill(0, 0, 255); // BLUE
      isColored = true;
    } else {
      fill(25,25,25);
    }

    let px = x * step;
    let py = y * step;

    // główne kółko
    circle(px, py, 5);

    // ⚪ biała kropka TYLKO dla liczb pierwszych
    if (isPrime(n)) {
      fill(255);
      circle(px, py, 2);
    }

    // ruch spirali
    x += dx;
    y += dy;
    segmentPassed++;

    if (segmentPassed === segmentLength) {
      segmentPassed = 0;

      let temp = dx;
      dx = -dy;
      dy = temp;

      segmentCount++;
      if (segmentCount % 2 === 0) {
        segmentLength++;
      }
    }
 
  
  }
 

}

